﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace VehicleConfigurator.Model
{
    public class InvoiceDetail
    {
        [Key]
        public int InvoiceDetailId { get; set; }
        [ForeignKey("InvoiceHeader")]
        public int InvoiceId { get; set; }
        public String? VehicleDescription { get; set; }

        public InvoiceHeader? InvoiceHeader { get; set; }
      
    }
}
